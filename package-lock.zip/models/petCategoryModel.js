
import mongoose from "mongoose"

const petCategorySchema = mongoose.Schema({
    name:{
        type:String
    
    },
    status:{
        type: String,
        default:1
    },
    created_at:{
        type: Date,
        default: () => Date.now()
    }
});

export default mongoose.model("petCategory",petCategorySchema);