import express from "express"
import VolunteerController from "../controllers/VolunteerController.js"
import Helper from "../helpers/Helper.js";
const router = express.Router()

router.get("/getProfile",Helper.verifyToken,Helper.authorizeUser,VolunteerController.getProfile);
router.put("/postProfile/:user",Helper.verifyToken,Helper.authorizeUser,VolunteerController.postProfile);




router.get("/getOccupation",Helper.verifyToken,VolunteerController.getOccupation);
router.get("/getState",Helper.verifyToken,VolunteerController.getState);



export default router